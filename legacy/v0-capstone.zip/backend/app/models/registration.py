"""Registration model — visitor registration pending admin approval."""

import uuid
from datetime import datetime

from sqlalchemy import DateTime, Enum, ForeignKey, String, Text, func
from sqlalchemy.dialects.postgresql import JSONB
from sqlalchemy.dialects.postgresql import UUID
from sqlalchemy.orm import Mapped, mapped_column

from app.core.database import Base
from app.services.encryption import EncryptedString


class Registration(Base):
    """Visitor registration form. Pending → approved/rejected by admin."""

    __tablename__ = "registrations"

    id_registration: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True), primary_key=True, default=uuid.uuid4
    )
    full_name: Mapped[str] = mapped_column(String(255), nullable=False)
    phone_whatsapp: Mapped[str] = mapped_column(EncryptedString(500), nullable=False)  # AES-256-GCM
    email: Mapped[str | None] = mapped_column(EncryptedString(500), nullable=True)  # AES-256-GCM
    address: Mapped[str | None] = mapped_column(Text, nullable=True)
    instrument: Mapped[str | None] = mapped_column(String(50), nullable=True)
    level: Mapped[str | None] = mapped_column(String(50), nullable=True)
    class_type: Mapped[str | None] = mapped_column(String(50), nullable=True)
    schedule_id: Mapped[str | None] = mapped_column(String(50), nullable=True)
    payment_proof_path: Mapped[str | None] = mapped_column(String(500), nullable=True)
    children_data: Mapped[dict | None] = mapped_column(JSONB, nullable=True)  # [{full_name, instrument, level}]
    status: Mapped[str] = mapped_column(
        Enum("pending", "approved", "rejected", name="registration_status"),
        nullable=False,
        default="pending",
    )
    reviewed_by: Mapped[uuid.UUID | None] = mapped_column(
        UUID(as_uuid=True), ForeignKey("users.id_user"), nullable=True
    )
    reviewed_at: Mapped[datetime | None] = mapped_column(
        DateTime(timezone=True), nullable=True
    )
    notes: Mapped[str | None] = mapped_column(Text, nullable=True)
    created_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), server_default=func.now(), nullable=False
    )
    deleted_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True), nullable=True)
